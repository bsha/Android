package com.example.basicapphw2_2;

import android.content.Context;
import android.content.res.Resources;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapter extends BaseAdapter {
    private Context mContext;

    public ImageAdapter(Context c) {
        mContext = c;
    }

    public int getCount() {
        return mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }
    
    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {  // if it's not recycled, initialize some attributes
            
        	//calculation of ImageView Size - density independent
        	Resources resources = Resources.getSystem();
        	float pixels = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 36, resources.getDisplayMetrics());
        	
        	imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams((int)pixels, (int)pixels));
            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            imageView.setPadding(0, 0, 0, 0);
        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[position]);
        return imageView;
    }

    // references to our images
    private Integer[] mThumbIds = {
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear, R.drawable.clear, R.drawable.clear,
            R.drawable.clear, R.drawable.clear
    };
}