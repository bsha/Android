package com.example.basicapphw2_2;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {

	int playerTurn = R.drawable.player1;
	int numRows = 6, numCols = 7;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		final ImageAdapter imageAdapter = new ImageAdapter(this);
		gridview.setAdapter(imageAdapter);

	    gridview.setOnItemClickListener(new OnItemClickListener() {
	        public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
	            int newPiece = turnIsOver(getColumnNumber(position, numCols));
	        	
	        	//check validity of move
	            if (newPiece != -1){
	            	
	            	if (currentPlayerWon(newPiece)){
	            		TextView gameWinner = (TextView) findViewById(R.id.C4Winner);
		        		gameWinner.setText("Game Over\n" + getCurrentPlayer() + " Won!!");
	            		enableDisableElements(false);
	            	}
	            	if (gameIsTie(newPiece)){
	            		TextView gameWinner = (TextView) findViewById(R.id.C4Winner);
		        		gameWinner.setText("Game Over\nTie Game.");
	            		enableDisableElements(false);
            		}
	            	
		            //change next player's turn
		            if (playerTurn == R.drawable.player1){
		            	playerTurn = R.drawable.player2;
		            	TextView whoseTurn = (TextView) findViewById(R.id.C4currentPlayer);
		        		whoseTurn.setText(getResources().getString(R.string.P2Turn));
		            }
		            else if (playerTurn == R.drawable.player2){
		            	playerTurn = R.drawable.player1;
		            	TextView whoseTurn = (TextView) findViewById(R.id.C4currentPlayer);
		            	whoseTurn.setText(getResources().getString(R.string.P1Turn));
		            }
	            }
	            
	        }
	    });
	    
	    Button newGameBtn = (Button) findViewById(R.id.C4newGame);
	    newGameBtn.setOnClickListener(new View.OnClickListener(){
	    	public void onClick(View v){
	    		GridView gridview = (GridView) findViewById(R.id.C4gridview);
	    		gridview.setAdapter(imageAdapter);
	    		playerTurn = R.drawable.player1;
	    		TextView whoseTurn = (TextView) findViewById(R.id.C4currentPlayer);
            	whoseTurn.setText(getResources().getString(R.string.P1Turn));
            	TextView gameWinner = (TextView) findViewById(R.id.C4Winner);
        		gameWinner.setText("");
        		enableDisableElements(true);
	    	}
	    });
	    
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void enableDisableElements(boolean state){
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		gridview.setEnabled(state);
		return;
	}
	
	//get column you are trying to place a piece
	public int getColumnNumber(int position, int numCols){
		return position % numCols;
	}
	
	public String getCurrentPlayer(){
		if (playerTurn == R.drawable.player1){
        	return "Player 1";
        }
		
		//if current player is not player 1, it must be player 2
        return "Player 2";
	}
	
	//returns position value on grid of new piece; if cannot make move, return -1
	public int turnIsOver(int column){
		// start checking from bottom row of chosen column
		int checkPosition = numCols * numRows + column - numRows - 1;
		
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		//Toast.makeText(MainActivity.this, "column " + column, Toast.LENGTH_SHORT).show();
		
		// loop through each element in that column
		while (checkPosition >= 0){
			ImageView imageView = (ImageView) gridview.getChildAt(checkPosition);
			
			if (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.clear).getConstantState())){
				imageView.setImageResource(playerTurn);
	            return checkPosition;
            }
            else {
            	checkPosition -= numCols;
            }
		}
		return -1;
	}
	
	public boolean WonWtoE(int position){
		int left = 0, right = 0, checkPosition = position - 1, column = getColumnNumber(position, numCols);
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		ImageView imageView;
		
		//check to the left
		if (checkPosition >= 0){
			imageView = (ImageView) gridview.getChildAt(checkPosition);
			while (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(playerTurn).getConstantState()) && getColumnNumber(checkPosition, numCols) < column && checkPosition >= 0){
				left++;
				checkPosition--;
				if (checkPosition < 0){
					break;
				}
				imageView = (ImageView) gridview.getChildAt(checkPosition);
			}
		}
		
		//check to the right
		checkPosition = position + 1;
		if (checkPosition <= numRows * numCols - 1){
			imageView = (ImageView) gridview.getChildAt(checkPosition);
			while (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(playerTurn).getConstantState()) && getColumnNumber(checkPosition, numCols) > column && checkPosition <= numRows * numCols - 1){
				right++;
				checkPosition++;
				if (checkPosition > numRows * numCols - 1){
					break;
				}
				imageView = (ImageView) gridview.getChildAt(checkPosition);
			}
		}
		
		//did player win?
		if (left + right + 1 >= 4){
			return true;
		}
		
		return false;
	}

	public boolean WonNWtoSE(int position){
		int left = 0, right = 0, checkPosition = position - 1 - numCols, column = getColumnNumber(position, numCols);
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		ImageView imageView;
		
		//check to the left
		if (checkPosition >= 0){
			imageView = (ImageView) gridview.getChildAt(checkPosition);
			while (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(playerTurn).getConstantState()) && getColumnNumber(checkPosition, numCols) < column && checkPosition >= 0){
				left++;
				checkPosition = checkPosition - 1 - numCols;
				if (checkPosition < 0){
					break;
				}
				imageView = (ImageView) gridview.getChildAt(checkPosition);
			}
		}
		 
		//check to the right
		checkPosition = position + 1 + numCols;
		if (checkPosition <= numRows * numCols - 1){
			imageView = (ImageView) gridview.getChildAt(checkPosition);
			while (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(playerTurn).getConstantState()) && getColumnNumber(checkPosition, numCols) > column && checkPosition <= numRows * numCols - 1){
				right++;
				checkPosition = checkPosition + 1 + numCols;
				if (checkPosition > numRows * numCols - 1){
					break;
				}
				imageView = (ImageView) gridview.getChildAt(checkPosition);
			}
		}
		
		//did player win?
		if (left + right + 1 >= 4){
			return true;
		}
		
		return false;
	}

	public boolean WonSWtoNE(int position){
		int left = 0, right = 0, checkPosition = position - 1 + numCols, column = getColumnNumber(position, numCols);
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		ImageView imageView;
		
		//check to the left
		if (checkPosition <= numRows * numCols - 1){
			imageView = (ImageView) gridview.getChildAt(checkPosition);
			while (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(playerTurn).getConstantState()) && getColumnNumber(checkPosition, numCols) < column && checkPosition <= numRows * numCols - 1){
				left++;
				checkPosition = checkPosition - 1 + numCols;
				if (checkPosition > numRows * numCols - 1){
					break;
				}
				imageView = (ImageView) gridview.getChildAt(checkPosition);
			}
		}
		 
		//check to the right
		checkPosition = position + 1 - numCols;
		if (checkPosition >= 0){
			imageView = (ImageView) gridview.getChildAt(checkPosition);
			while (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(playerTurn).getConstantState()) && getColumnNumber(checkPosition, numCols) > column && checkPosition >= 0){
				right++;
				checkPosition = checkPosition + 1 - numCols;
				if (checkPosition < 0){
					break;
				}
				imageView = (ImageView) gridview.getChildAt(checkPosition);
			}
		}
		
		//did player win?
		if (left + right + 1 >= 4){
			return true;
		}
		
		return false;
	}

	public boolean WonNtoS(int position){
		int down = 0, checkPosition = position + numCols;
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		ImageView imageView;
		
		//check downwards
		if (checkPosition <= numRows * numCols - 1){
			imageView = (ImageView) gridview.getChildAt(checkPosition);
			while (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(playerTurn).getConstantState()) && checkPosition <= numRows * numCols - 1){
				down++;
				checkPosition = checkPosition + numCols;
				if (checkPosition > numRows * numCols - 1){
					break;
				}
				imageView = (ImageView) gridview.getChildAt(checkPosition);
			}
		}
		 
		//did player win?
		if (down + 1 >= 4){
			return true;
		}
		
		return false;
	}
	
	public boolean currentPlayerWon(int position){
		if (WonNWtoSE(position)){
			return true;
		}
		if (WonNtoS(position)){
			return true;
		}
		if (WonSWtoNE(position)){
			return true;
		}
		if (WonWtoE(position)){
			return true;
		}
		return false;
	}
	
	public boolean gameIsTie(int position){
		if (position > numCols){
			return false;
		}
		
		GridView gridview = (GridView) findViewById(R.id.C4gridview);
		ImageView imageView;
		
		for (int column = 0; column < numCols; column++){
			imageView = (ImageView) gridview.getChildAt(column);
			if (imageView.getDrawable().getConstantState().equals(getResources().getDrawable(R.drawable.clear).getConstantState())){
				return false;
			}
		}
		return true;
	}

}
